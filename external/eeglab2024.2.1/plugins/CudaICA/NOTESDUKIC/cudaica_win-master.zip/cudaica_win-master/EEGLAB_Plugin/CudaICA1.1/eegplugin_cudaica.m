function vers = eegplugin_cudaica(fig,try_strings,catch_strings) %#ok<INUSD>

vers = 'CUDAICA_v1.1';

addpath(fileparts(which(mfilename)));

end

